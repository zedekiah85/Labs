/*Ume Farva, CIS 242, 08 / 07 / 2024  James Papademas */

#include <iostream>
#include <string>

using namespace std;

class Employee {
protected:
    string empID;
    string empName;
    float hourlyRate;
    float grossPay;
    int hoursWorked;

public:
    // Constructor
    Employee(string id, string name, float rate, int hours)
        : empID(id), empName(name), hourlyRate(rate), hoursWorked(hours) {
        cout << "Employee is being constructed." << endl;
        grossPay = hourlyRate * hoursWorked;
    }

    // Default constructor
    Employee() : hourlyRate(0), grossPay(0), hoursWorked(0) {
        cout << "Default Employee is being constructed." << endl;
    }

    // Member functions
    void SetEmpID(string id) {
        empID = id;
    }

    string GetEmpID() {
        return empID;
    }

    void SetName(string name) {
        empName = name;
    }

    string GetName() {
        return empName;
    }

    void SetHourlyRate(float rate) {
        hourlyRate = rate;
    }

    float GetHourlyRate() {
        return hourlyRate;
    }

    void SetHoursWorked(int hours) {
        hoursWorked = hours;
    }

    int GetHoursWorked() {
        return hoursWorked;
    }

    float GetGrossPay() {
        grossPay = hourlyRate * hoursWorked;
        return grossPay;
    }

    void Display() {
        cout << "Employee Record - Hourly Wage Employee" << endl;
        cout << "ID Number: " << empID << endl;
        cout << "Name: " << empName << endl;
        cout << "Hours Worked: " << hoursWorked << endl;
        cout << "Hourly Wage: $" << hourlyRate << endl;
        cout << "Gross Pay: $" << GetGrossPay() << endl;
    }
};

class SalaryEmployee : public Employee {
private:
    float annualSalary;

public:
    // Constructor
    SalaryEmployee(string id, string name, float salary)
        : Employee(id, name, 0, 0), annualSalary(salary) {
        cout << "Salaried Employee is being constructed." << endl;
    }

    // Default constructor
    SalaryEmployee() : Employee(), annualSalary(0) {
        cout << "Default Salaried Employee is being constructed." << endl;
    }

    // Member functions
    void SetAnnualSalary(float salary) {
        annualSalary = salary;
    }

    float GetAnnualSalary() {
        return annualSalary;
    }

    float GetGrossPay() {
        grossPay = annualSalary / 26;
        return grossPay;
    }

    void Display() {
        cout << "Employee Record - Salaried Employee" << endl;
        cout << "ID Number: " << empID << endl;
        cout << "Name: " << empName << endl;
        cout << "Annual Salary: $" << annualSalary << endl;
        cout << "Bi-Weekly Gross Pay: $" << GetGrossPay() << endl;
    }
};

int main() {
    // Test the Employee class
    Employee emp("805", "Sammy Student", 10.00, 38);
    emp.Display();

    // Test the SalaryEmployee class
    SalaryEmployee salEmp("837", "Samantha Student", 38000.00);
    salEmp.Display();

    return 0;
}
