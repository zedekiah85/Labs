/* UME FARVA, CIS 242, 26/07/2024, JAMES PAPADEMAS */
#include <iostream>
#include <vector>
#include <queue>
#include <map>
#include <algorithm>

using namespace std;

// Structure to represent a Task
struct Task {
    int id;
    double duration;
    vector<int> dependencies;

    Task(int id, double duration, vector<int> dependencies)
        : id(id), duration(duration), dependencies(dependencies) {}
};

// Function to process tasks and schedule them
void processTasks(vector<Task>& tasks) {
    map<int, int> inDegree; // Track the number of incoming edges (dependencies)
    map<int, vector<int>> adjList; // Adjacency list for the graph
    queue<int> readyQueue; // Queue to manage ready tasks

    // Initialize inDegree and adjList
    for (const auto& task : tasks) {
        inDegree[task.id] = 0;
        adjList[task.id] = vector<int>();
    }

    // Build the graph
    for (const auto& task : tasks) {
        for (int dep : task.dependencies) {
            adjList[dep].push_back(task.id);
            inDegree[task.id]++;
        }
    }

    // Enqueue tasks with no dependencies
    for (const auto& task : tasks) {
        if (inDegree[task.id] == 0) {
            readyQueue.push(task.id);
        }
    }

    // Process tasks in topological order
    double currentTime = 0;
    while (!readyQueue.empty()) {
        int current = readyQueue.front();
        readyQueue.pop();

        // Output the current task
        cout << "Processing task " << current << " at time " << currentTime << endl;

        // Update the current time by adding task duration
        currentTime += find_if(tasks.begin(), tasks.end(),
            [current](const Task& t) { return t.id == current; })->duration;

        // Update the graph and enqueue tasks that are now ready
        for (int neighbor : adjList[current]) {
            inDegree[neighbor]--;
            if (inDegree[neighbor] == 0) {
                readyQueue.push(neighbor);
            }
        }
    }

    cout << "All tasks processed. Total time: " << currentTime << endl;
}

int main() {
    int numTasks;

    cout << "Enter the number of tasks: ";
    cin >> numTasks;

    vector<Task> tasks;

    for (int i = 0; i < numTasks; ++i) {
        int id, numDeps;
        double duration;
        cout << "Enter task ID: ";
        cin >> id;

        // Validate duration input
        while (true) {
            cout << "Enter task duration: ";
            cin >> duration;
            if (cin.fail() || duration <= 0) {
                cout << "Invalid input. Please enter a positive number for duration." << endl;
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }
            else break;
        }

        // Validate number of dependencies input
        while (true) {
            cout << "Enter the number of dependencies: ";
            cin >> numDeps;
            if (cin.fail() || numDeps < 0) {
                cout << "Invalid input. Please enter a non-negative integer for number of dependencies." << endl;
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }
            else break;
        }

        vector<int> dependencies(numDeps);
        for (int j = 0; j < numDeps; ++j) {
            // Validate dependency input
            while (true) {
                cout << "Enter dependency " << j + 1 << ": ";
                cin >> dependencies[j];
                if (cin.fail()) {
                    cout << "Invalid input. Please enter a valid task ID for dependency." << endl;
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                }
                else break;
            }
        }

        tasks.push_back(Task(id, duration, dependencies));
    }

    // Process the tasks
    processTasks(tasks);

    return 0;
}
