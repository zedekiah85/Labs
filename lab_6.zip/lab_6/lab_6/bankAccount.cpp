/*Ume Farva, CIS 242, 09/07/2024, James Papademas */

#include <iostream>
using namespace std;

class BankAccount {
public:
    BankAccount(int = 0, float = 0);
    void deposit(float amount) { bal += amount; }
    int account_num() const { return acctnum; }
    float balance() const { return bal; }
    virtual void print() = 0; // pure virtual function
protected:
    int acctnum;
    float bal;
};

// constructor for BankAccount; both args can default to zero
BankAccount::BankAccount(int num, float ibal) {
    acctnum = num;
    bal = ibal;
}

class Checking : public BankAccount {
public:
    Checking(int num, float ibal) : BankAccount(num, ibal) {}
    void withdraw(float amount);
    void print();
};

void Checking::withdraw(float amount) {
    if (bal - amount < 0) {
        cout << "Insufficient funds for withdrawal." << endl;
    }
    else {
        bal -= amount;
        if (bal < 1000) {
            bal -= 0.50; // charge $0.50 fee if balance falls below $1000
        }
    }
}

void Checking::print() {
    cout << "Checking Account Number: " << acctnum << endl;
    cout << "Balance: $" << bal << endl;
}

class Savings : public BankAccount {
public:
    Savings(int num, float ibal) : BankAccount(num, ibal) {}
    void withdraw(float amount);
    void print();
};

void Savings::withdraw(float amount) {
    if (bal - amount < 0) {
        cout << "Insufficient funds for withdrawal." << endl;
    }
    else {
        bal -= amount;
    }
}

void Savings::print() {
    cout << "Savings Account Number: " << acctnum << endl;
    cout << "Balance: $" << bal << endl;
}

int main() {
    // Create checking and savings account objects
    Checking checker(1001, 1200);
    Savings saver(2001, 1500);

    // Perform deposits and withdrawals
    checker.deposit(300);
    checker.deposit(200);
    checker.withdraw(1500); // This will drop balance below 1000 and charge $0.50 fee
    checker.withdraw(100);

    saver.deposit(500);
    saver.deposit(300);
    saver.withdraw(2000); // This will be disallowed
    saver.withdraw(200);

    // Create an array of base class pointers
    BankAccount* accounts[2];
    accounts[0] = &checker;
    accounts[1] = &saver;

    // Report on account balances
    for (int i = 0; i < 2; i++) {
        accounts[i]->print();
    }

    return 0;
}
