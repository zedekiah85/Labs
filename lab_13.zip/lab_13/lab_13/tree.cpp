/* UME FARVA, CIS 242, 26/07/2024, JAMES PAPADEMAS */

#include <iostream>
using namespace std;

// Function to find the maximum node
void findMaxNode(int arr[], int size) {
    int max = arr[0];
    for (int i = 1; i < size; i++) {
        if (arr[i] > max)
            max = arr[i];
    }
    cout << "The maximum node value is: " << max << endl;
    cout << endl;
}

// Function to find the minimum node
void findMinNode(int arr[], int size) {
    int min = arr[0];
    for (int i = 1; i < size; i++) {
        if (arr[i] < min)
            min = arr[i];
    }
    cout << "The minimum node value is: " << min << endl;
    cout << endl;
}

// Function to print all the nodes of the tree
void printNodes(int arr[], int size) {
    cout << "Node values: ";
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

// Function to insert a node in the tree
void insertNode(int arr[], int& size) {
    int indexToInsert = 0;
    cout << "Where would you like to insert a node? ";
    cout << "{ 1->2, 2->7, 3->5, 4->2, 5->6, 6->9, 7->5, 8->11, 9->4 } ";
    cin >> indexToInsert;
    indexToInsert -= 1; // Convert to zero-based array

    if (indexToInsert < 0 || indexToInsert > size) {
        cout << "Invalid index!" << endl;
        return;
    }

    int newValue;
    cout << "What value is to be inserted? ";
    cin >> newValue;

    int* newArray = new int[size + 1];
    for (int i = 0, j = 0; i < size + 1; i++) {
        if (i == indexToInsert) {
            newArray[i] = newValue;
        }
        else {
            newArray[i] = arr[j++];
        }
    }

    size++;
    for (int i = 0; i < size; i++) {
        arr[i] = newArray[i];
    }

    delete[] newArray;
    printNodes(arr, size);
}

// Function to delete a node from the tree
void deleteNode(int arr[], int& size) {
    int valueToDelete;
    cout << "Enter the value of the node to delete: ";
    cin >> valueToDelete;

    int indexToDelete = -1;
    for (int i = 0; i < size; i++) {
        if (arr[i] == valueToDelete) {
            indexToDelete = i;
            break;
        }
    }

    if (indexToDelete == -1) {
        cout << "Node not found!" << endl;
        return;
    }

    for (int i = indexToDelete; i < size - 1; i++) {
        arr[i] = arr[i + 1];
    }

    size--;
    printNodes(arr, size);
}

// Function to search for a node in the tree
void searchNode(int arr[], int size) {
    int valueToSearch;
    cout << "Enter the value of the node to search: ";
    cin >> valueToSearch;

    for (int i = 0; i < size; i++) {
        if (arr[i] == valueToSearch) {
            cout << "Node found at index " << i << endl;
            return;
        }
    }

    cout << "Node not found!" << endl;
}

// Function to display the menu and handle user input
void displayMenu() {
    int nodeVals[] = { 2, 7, 5, 2, 6, 9, 5, 11, 4 };
    const int initialSize = sizeof(nodeVals) / sizeof(nodeVals[0]);
    int size = initialSize;

    while (true) {
        cout << "\nBinary Tree Operations Menu:\n";
        cout << "1. Find the maximum node\n";
        cout << "2. Find the minimum node\n";
        cout << "3. Print all nodes\n";
        cout << "4. Insert a node\n";
        cout << "5. Delete a node\n";
        cout << "6. Search for a node\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";

        int choice;
        cin >> choice;

        switch (choice) {
        case 1:
            findMaxNode(nodeVals, size);
            break;
        case 2:
            findMinNode(nodeVals, size);
            break;
        case 3:
            printNodes(nodeVals, size);
            break;
        case 4:
            insertNode(nodeVals, size);
            break;
        case 5:
            deleteNode(nodeVals, size);
            break;
        case 6:
            searchNode(nodeVals, size);
            break;
        case 7:
            cout << "Exiting program." << endl;
            return;
        default:
            cout << "Invalid choice! Please try again." << endl;
        }
    }
}

int main() {
    displayMenu();
    return 0;
}
