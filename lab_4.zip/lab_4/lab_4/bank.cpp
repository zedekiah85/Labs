/* Ume Farva, CIS 242, 08/07/2024, James Papademas */
#include <iostream>
#include <string>
using namespace std;

class Account {
private:
    float fBalance;
    float fAmount;
    char cType;
    string stDescription;

public:
    // Class Constructor to initialize the account balance and member variables
    Account() : fBalance(0.0), fAmount(0.0), cType('\0') {
        cout << "Enter initial account balance: ";
        cin >> fBalance;
    }

    // Public method to control program execution
    void Run() {
        char cont;
        do {
            ObtainData();
            Calculate();
            PrintReport();
            cout << "Do you want to perform another transaction? (y/n): ";
            cin >> cont;
        } while (cont == 'y' || cont == 'Y');
    }

    // Method to prompt and input transaction type and amount
    void ObtainData() {
        cout << "Enter transaction type (d for deposit, w for withdrawal): ";
        cin >> cType;
        cout << "Enter amount of transaction: ";
        cin >> fAmount;
    }

    // Method to calculate account balance after new transaction
    void Calculate() {
        if (cType == 'd' || cType == 'D') {
            stDescription = "Deposit";
            fBalance += fAmount;
        }
        else if (cType == 'w' || cType == 'W') {
            stDescription = "Withdrawal";
            fBalance -= fAmount;
        }
        else {
            stDescription = "Invalid";
            cout << "Invalid Transaction Type" << endl;
        }
    }

    // Method to generate a formatted report
    void PrintReport() {
        cout << "Transaction Description: " << stDescription << endl;
        cout << "Transaction Amount: " << fAmount << endl;
        cout << "Account Balance: " << fBalance << endl;
    }
};

int main() {
    Account myAccount;
    myAccount.Run();
    return 0;
}
